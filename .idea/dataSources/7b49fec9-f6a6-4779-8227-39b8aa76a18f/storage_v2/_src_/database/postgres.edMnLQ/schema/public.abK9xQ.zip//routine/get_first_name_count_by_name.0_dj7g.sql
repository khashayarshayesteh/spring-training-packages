create function get_first_name_count_by_name(first_name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    first_name_count integer;
BEGIN
    SELECT COUNT(*)
    INTO first_name_count
    FROM employees
    WHERE first_name = last_name;

    RETURN first_name_count;
END
$$;

alter function get_first_name_count_by_name(varchar) owner to postgres;

