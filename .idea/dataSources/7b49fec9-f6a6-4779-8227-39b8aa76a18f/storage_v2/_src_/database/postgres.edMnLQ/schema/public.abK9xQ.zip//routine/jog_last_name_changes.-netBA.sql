create function jog_last_name_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    if new.lastname <> old.last_name then
        insert into mentor_audit(mentor_id, last_name, changed_on)
        VALUES (old.id, old.last_name, now());
    end if;
    return new;

end
$$;

alter function jog_last_name_changes() owner to postgres;

