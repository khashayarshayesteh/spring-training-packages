create function get_jobid_count_by_name(job_name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    jobId_count integer;
BEGIN
    SELECT COUNT(*)
    INTO jobId_count
    FROM employees
    WHERE job_id = job_name;

    RETURN jobId_count;
END
$$;

alter function get_jobid_count_by_name(varchar) owner to postgres;

