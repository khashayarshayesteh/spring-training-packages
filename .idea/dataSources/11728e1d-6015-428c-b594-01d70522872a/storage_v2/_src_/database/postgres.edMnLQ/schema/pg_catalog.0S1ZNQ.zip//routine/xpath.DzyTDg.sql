create function xpath(text, xml) returns xml[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function xpath(text, xml, text[]) is 'evaluate XPath expression, with namespaces support';

alter function xpath(text, xml, text[]) owner to postgres;

